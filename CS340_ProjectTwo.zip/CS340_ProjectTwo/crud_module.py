from pymongo import MongoClient
from bson.objectid import ObjectId

class AnimalShelter(object):
    """CRUD operations for Animal collection in MongoDB"""

    def __init__(self, username, password):
        # MongoDB Host Information
        HOST = 'nv-desktop-services.apporto.com'
        PORT = 32704
        DB = 'AAC'
        
        # Initializing the MongoClient to connect to the MongoDB database
        self.client = MongoClient(f'mongodb://{username}:{password}@{HOST}:{PORT}/{DB}')
        self.database = self.client[DB]
        self.collection = self.database['animals']
    
    def create(self, data):
        """Inserts a document into the collection."""
        if data is not None:
            result = self.collection.insert_one(data)
            return True if result.inserted_id else False
        else:
            raise Exception("Nothing to save, because data parameter is empty")
    
    def read(self, query=None):
        """Queries documents from the collection."""
        query = query or {}
        results = self.collection.find(query)
        return list(results)
    
    def update(self, query, new_values):
        """Updates documents in the collection."""
        if query is not None and new_values is not None:
            result = self.collection.update_many(query, {'$set': new_values})
            return result.modified_count
        else:
            raise Exception("Query or new values missing")
    
    def delete(self, query):
        """Deletes documents from the collection."""
        if query is not None:
            result = self.collection.delete_many(query)
            return result.deleted_count
        else:
            raise Exception("Query missing for delete operation")

